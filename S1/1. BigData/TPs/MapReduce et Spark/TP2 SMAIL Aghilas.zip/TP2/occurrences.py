def compter_occurrences_fichier(nom_fichier):
    # un dictionnaire pour les occurrences de mots
    occurrences = {}
    
    with open(nom_fichier, 'r', encoding='utf-8') as fichier:
        for ligne in fichier:
            mots = ligne.split()
            
            for mot in mots:                           
                if mot in occurrences:
                    occurrences[mot] += 1
                else:
                    occurrences[mot] = 1
    
    return occurrences

nom_fichier = "hamlet.txt"

resultat = compter_occurrences_fichier(nom_fichier)

for mot, occ in resultat.items():
    print(f"le mot {mot} apparait {occ}")
